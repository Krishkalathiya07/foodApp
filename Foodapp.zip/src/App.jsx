
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import './App.css'
import { FooterTwo } from './pages/Footer'
import { Login } from './pages/Login'
import { Navbar } from './pages/Navbar'
import ProductCard from './pages/ProductCard'

function App() {
  return (
    <>


      <BrowserRouter>
        <Routes>
          <Route path='/' element={<Navbar />} />
          <Route path='/' element={<ProductCard />} />
          <Route path='/' element={<Navbar />} />
          <Route path='/'  element={<FooterTwo /> }/>
          <Route path='/login' element={<Login />} />
        </Routes>
      </BrowserRouter>
      </>
  )
}

export default App
